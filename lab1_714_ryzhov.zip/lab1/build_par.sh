mpicc parallel.c -o parallel -lm
