#include "mpi.h"
#include "stdio.h"
#include "malloc.h"
#include "stdlib.h"
#include "math.h"

void psi(double* u, double t_min, double t_max, double t_step, int t_n, int x_n);
void phi(double* u, double x_min, double x_max, double x_step, int x_n, int t_n);
double f(double x, double t);
void master(int n, int np);
void slave(int n, int np);

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int np;
    MPI_Comm_size(MPI_COMM_WORLD, &np);
    int rank = 0;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {
        master(rank, np);
    }
    else {
        slave(rank, np);
    }

    MPI_Finalize();

    return 0;
}

void master(int n, int np){
    //determination of boundary and initial conditions
    double x_min = 0;
    double x_max = 1;
    double x_step = 0.002;
    int x_n = (x_max-x_min)/x_step+1;

    double t_min = 0;
    double t_max = 1;
    double t_step = 0.001;
    int t_n = (t_max-t_min)/t_step + 1;

    double a = 1;
    double* u = (double*)calloc(x_n * t_n, sizeof(double));

    psi(u, t_min, t_max, t_step, t_n, x_n);
    phi(u, x_min, x_max, x_step, x_n, t_n);

    int i = 0;
    int j = 0;

    //Sending tasks to other processes
    int segment[2];
    for(i = 1; i < np; i++){
        segment[0] = (i-1) * (int)(x_n/np) + 1;
        segment[1] = i * (int)(x_n/np);
        MPI_Send(segment, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
    }
    segment[0] = (i-1) * (int)(x_n/np) + 1;
    segment[1] = x_n-1;

    printf("Process %d received task: [%d - %d]\n", n, segment[0], segment[1]);
    //Calculations
    double u_buffer = 0;

    i = 1;
    //Explicit central three-point scheme
    for(j = segment[0]; j < segment[1]; j++){
        u[i*x_n+j] = u[(i-1)*x_n+(j+1)]*(0.5-t_step/2/x_step) + u[(i-1)*x_n+(j-1)]*(0.5+t_step/2/x_step) + t_step*f(j*x_step, i*t_step);
        if(j == segment[0]){
            u_buffer = u[i*x_n+j];
            MPI_Send(&u_buffer, 1, MPI_DOUBLE, np-1, 0, MPI_COMM_WORLD);
        }
    }
    //Explicit left corner scheme
    u[i*x_n+segment[1]]=u[(i-1)*x_n+segment[1]]*(1-t_step/x_step) +  t_step/x_step*u[(i-1)*x_n+segment[1]-1] + t_step*f(j*x_step, i*t_step);

    for(i = 2; i < t_n; i++){
        MPI_Recv(&u_buffer, 1, MPI_DOUBLE, np-1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        u[(i-1)*x_n+segment[0]-1] = u_buffer;

        //Explicit central three-point scheme
        for(j = segment[0]; j < segment[1]; j++){
            u[i*x_n+j] = u[(i-1)*x_n+(j+1)]*(0.5-t_step/2/x_step) + u[(i-1)*x_n+(j-1)]*(0.5+t_step/2/x_step) + t_step*f(j*x_step, i*t_step);
            if(j == segment[0]){
                u_buffer = u[i*x_n+j];
                MPI_Send(&u_buffer, 1, MPI_DOUBLE, np-1, 0, MPI_COMM_WORLD);
            }
        }
        //Explicit left corner scheme
        u[i*x_n+segment[1]]=u[(i-1)*x_n+segment[1]]*(1-t_step/x_step) +  t_step/x_step*u[(i-1)*x_n+segment[1]-1] + t_step*f(j*x_step, i*t_step);
    }

    //Receiving results from other processes
    double* buffer = (double*)calloc(((int)(x_n/np))*(t_n-1), sizeof(double));
    for(i = 1; i < np; i++){
        int p = 0;
        MPI_Recv(buffer, ((int)(x_n/np))*(t_n-1), MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        for(j = 1; j < t_n; j++){
            int k = 0;
            for(k = (i-1) * ((int)(x_n/np)) + 1; k < i * ((int)(x_n/np)) + 1; k++){
                u[j*x_n+k] = buffer[p];
                p++;
            }
        }
    }

    //saving the results
    FILE * file;
    file = fopen ("results_par.txt","w");
    for(i = 0; i < t_n; i++){
        for(j = 0; j < x_n; j++){
            fprintf (file, "%lf\n",u[i*x_n+j]);
        }
    }
    fclose (file);

    free(buffer);
    free(u);

    return;
};

void slave(int n, int np){
    //determination of boundary and initial conditions
    double x_min = 0;
    double x_max = 1;
    double x_step = 0.002;
    int x_n = (x_max-x_min)/x_step+1;

    double t_min = 0;
    double t_max = 1;
    double t_step = 0.001;
    int t_n = (t_max-t_min)/t_step + 1;

    double a = 1;
    double* u = (double*)calloc(x_n * t_n, sizeof(double));

    psi(u, t_min, t_max, t_step, t_n, x_n);
    phi(u, x_min, x_max, x_step, x_n, t_n);

    int i = 0;
    int j = 0;

    //Receiving task from main process
    int segment[2];
    MPI_Recv(segment, 2, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    printf("Process %d received task: [%d - %d]\n", n, segment[0], segment[1]);

    //Calculations
    double u_buffer = 0;

    i = 1;
    //Explicit central three-point scheme
    for(j = segment[0]; j < segment[1]+1; j++){
        u[i*x_n+j] = u[(i-1)*x_n+(j+1)]*(0.5-t_step/2/x_step) + u[(i-1)*x_n+(j-1)]*(0.5+t_step/2/x_step) + t_step*f(j*x_step, i*t_step);
        if(j == segment[0] && n != 1){
            u_buffer = u[i*x_n+j];
            MPI_Send(&u_buffer, 1, MPI_DOUBLE, n-1, 0, MPI_COMM_WORLD);
        } else if(j == segment[1]){
            u_buffer = u[i*x_n+j];
            MPI_Send(&u_buffer, 1, MPI_DOUBLE, (n+1)%np, 0, MPI_COMM_WORLD);
        }
    }

    for(i = 2; i < t_n; i++){
        if(n != 1){
            MPI_Recv(&u_buffer, 1, MPI_DOUBLE, n-1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            u[(i-1)*x_n+segment[0]-1] = u_buffer;
        }

        //Explicit central three-point scheme
        for(j = segment[0]; j < segment[1]+1; j++){
            u[i*x_n+j] = u[(i-1)*x_n+(j+1)]*(0.5-t_step/2/x_step) + u[(i-1)*x_n+(j-1)]*(0.5+t_step/2/x_step) + t_step*f(j*x_step, i*t_step);
            if(j == segment[0] && n != 1){
                u_buffer = u[i*x_n+j];
                MPI_Send(&u_buffer, 1, MPI_DOUBLE, n-1, 0, MPI_COMM_WORLD);
            } else if(j == segment[1] && i != t_n-1){
                u_buffer = u[i*x_n+j];
                MPI_Send(&u_buffer, 1, MPI_DOUBLE, (n+1)%np, 0, MPI_COMM_WORLD);
            } else if(j == segment[1]-1){
                MPI_Recv(&u_buffer, 1, MPI_DOUBLE, (n+1)%np, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                u[(i-1)*x_n+segment[1]+1] = u_buffer;
            }
        }
    }

    //Sending results to main process
    double* buffer = (double*)calloc((int)(x_n/np)*(t_n-1), sizeof(double));
    i = 0;
    int k = 0;
    for(j = 1; j < t_n; j++){
        for(k = segment[0]; k < segment[1]+1; k++){
            buffer[i] = u[j*x_n+k];
            i++;
        }
    }

    MPI_Send(buffer, ((int)(x_n/np))*(t_n-1), MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

    free(buffer);
    free(u);

    return;
};

void psi(double* u, double t_min, double t_max, double t_step, int t_n, int x_n){
    int i = 0;
    for(i = 0; i < t_n; i++){
        u[i*x_n]=sin(t_min+i*t_step);
    }
}

void phi(double* u, double x_min, double x_max, double x_step, int x_n, int t_n){
    int i = 0;
    for(i = 0; i < x_n; i++){
        u[i]=sin(x_min+i*x_step);
    }
}

double f(double x, double t){
    return exp(x+t);
}


