import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d

f = open("results_par.txt", 'r')
line = f.readlines()
U = []
for i in range(0,len(line)):
    U.append(float(line[i]))

x = np.arange(0, 1 + 0.002, 0.002)
t = np.arange(0, 1 + 0.001, 0.001)

X = []
T = []

for i in range(0,len(t)):
    for j in x:
        X.append(j)
for i in t:
    for j in x:
        T.append(i)

fig = plt.figure(figsize = (10,5))
ax = fig.add_subplot(1, 1, 1, projection='3d')
ax.plot_trisurf(T, X, U, linewidth=0.2, antialiased=True)
ax.set_title('solution from parallel programm')
ax.set_xlabel('t axis')
ax.set_ylabel('x axis')
ax.set_zlabel('u axis')
plt.show()

plt.savefig('solution_par.png')