
#include "stdio.h"
#include "malloc.h"
#include "stdlib.h"
#include "math.h"

void psi(double* u, double t_min, double t_max, double t_step, int t_n, int x_n);
void phi(double* u, double x_min, double x_max, double x_step, int x_n, int t_n);
double f(double x, double t);

int main(int argc, char** argv){
    //determination of boundary and initial conditions
    double x_min = 0;
    double x_max = 1;
    double x_step = 0.002;
    int x_n = (x_max-x_min)/x_step+1;

    double t_min = 0;
    double t_max = 1;
    double t_step = 0.001;
    int t_n = (t_max-t_min)/t_step + 1;

    double a = 1;
    double* u = (double*)calloc(x_n * t_n, sizeof(double));

    psi(u, t_min, t_max, t_step, t_n, x_n);
    phi(u, x_min, x_max, x_step, x_n, t_n);

    int i = 0;
    int j = 0;

    for(i = 1; i < t_n; i++){
        //Explicit central three-point scheme
        for(j = 1; j < x_n-1; j++){
            u[i*x_n+j] = u[(i-1)*x_n+(j+1)]*(0.5-t_step/2/x_step) + u[(i-1)*x_n+(j-1)]*(0.5+t_step/2/x_step) + t_step*f(j*x_step, i*t_step);
        }
        //Explicit left corner scheme
        u[i*x_n+x_n-1]=u[(i-1)*x_n+x_n-1]*(1-t_step/x_step) +  t_step/x_step*u[(i-1)*x_n+x_n-2] + t_step*f(j*x_step, i*t_step);
    }

    //saving the results
    FILE * file;
    file = fopen ("results_seq.txt","w");
    for(i = 0; i < t_n; i++){
        for(j = 0; j < x_n; j++){
            fprintf (file, "%lf\n",u[i*x_n+j]);
        }
    }
    fclose (file);
    free(u);
    return 0;
};

void psi(double* u, double t_min, double t_max, double t_step, int t_n, int x_n){
    int i = 0;
    for(i = 0; i < t_n; i++){
        u[i*x_n]=sin(t_min+i*t_step);
    }
}

void phi(double* u, double x_min, double x_max, double x_step, int x_n, int t_n){
    int i = 0;
    for(i = 0; i < x_n; i++){
        u[i]=sin(x_min+i*x_step);
    }
}

double f(double x, double t){
    return exp(x+t);
}
