mpicc sequent.c -o sequent -lm
