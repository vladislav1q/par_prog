#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

double sum1 = 0;
double sum2 = 0;
double step = 0;
double x_left = 0;
double x_right = 0;
int n_steps = 0;
pthread_mutex_t mutex;

void* integrate(void* data);
double f1(double x);
double f2(double x);

//В качестве доп задачи взял интеграл exp(-x^2)dx

int main(int argc, char *argv[]){
    //get launch parameters
    step = atof(argv[1]);               //size of one step
    x_left = atof(argv[2]);             //start
    x_right = atof(argv[3]);            //end
    double width = atof(argv[4]);       //width per thread
    int n_threads = (x_right-x_left)/width;
    n_steps = width/step;
    //pthread objects initiatization
    pthread_t tid[n_threads];
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_mutex_init(&mutex, NULL);

    struct timespec begin,end;
    double elapsed;
    clock_gettime(CLOCK_REALTIME, &begin);

    //sent borders of summarizing
    int* borders = (int*)calloc(n_threads,sizeof(int));
    for(int i = 0; i < n_threads; i++){
	    borders[i] = i;
        pthread_create(tid+i,&attr,integrate,borders+i);
    }

    //waiting for threads
    for(int i = 0; i < n_threads; i++){
        pthread_join(*(tid+i),NULL);
    }

    clock_gettime(CLOCK_REALTIME, &end);
    elapsed = end.tv_sec-begin.tv_sec;
    elapsed += (end.tv_nsec-begin.tv_nsec)/1000000000.0;
    printf("Time of total execution: %f sec\n", elapsed);
    printf("The result of integrating xdx (%f,%f) on %d threads is %f\n", x_left, x_right, n_threads, sum1);
    printf("The result of integrating exp(-x^2)dx (%f,%f) on %d threads is %f\n", x_left, x_right, n_threads, sum2);

    pthread_mutex_destroy(&mutex);
    free(borders);

    return 0;
}

void* integrate(void* data){
    struct timespec begin,end;
    double elapsed;
    clock_gettime(CLOCK_REALTIME, &begin);

    //integrating
    int id = *((int*)data);
    double local_sum1 = 0;
    double local_sum2 = 0;
    for(double i = x_left+id*n_steps*step; i < x_left+ (id+1)*n_steps*step; i += step){
        local_sum1 += step*(f1(i)+f1(i+step))/2;
        local_sum2 += step*(f2(i)+f2(i+step))/2;
    }

    //add local result to global var sum
    pthread_mutex_lock(&mutex);
    sum1 += local_sum1;
    sum2 += local_sum2;
    pthread_mutex_unlock(&mutex);

    clock_gettime(CLOCK_REALTIME, &end);
    elapsed = end.tv_sec-begin.tv_sec;
    elapsed += (end.tv_nsec-begin.tv_nsec)/1000000000.0;
    printf("Time of execution on thread: %f sec\n", elapsed);

    pthread_exit(0);
}

double f1(double x){
    return x;
}
double f2(double x){
    return exp(-x*x);
}

