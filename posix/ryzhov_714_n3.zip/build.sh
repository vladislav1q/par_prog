gcc task3.c -o task3 -pthread -lrt -lm
