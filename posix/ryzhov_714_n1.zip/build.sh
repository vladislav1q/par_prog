gcc task1.c -o task1 -lpthread

