#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void* func(void* data);

int main(int argc, char *argv[])
{
    pthread_t tid;
    pthread_attr_t attr;
    int n = atoi(argv[1]);
    printf("Total number of threads: %d\n", n);

    pthread_attr_init(&attr);

    int* ids = (int*)calloc(n,sizeof(int));
    int i = 0;
    for(i = 0; i < n; i++){
	ids[i]=i+1;
        pthread_create(&tid,&attr,func,ids+i);
    }

    pthread_join(tid,NULL);

    return 0;
}

void* func(void* data)
{
    printf("My id is %d\n", *((int*)data));

    pthread_exit(0);
}

