#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
unsigned long int sum = 0;
pthread_mutex_t mutex;

void* summarize(void* data);

int main(int argc, char *argv[]){
    //get launch parameters
    int n_threads = atoi(argv[1]);
    int n_numbers = atoi(argv[2]);
    //pthread objects initiatization
    pthread_t tid[n_threads];
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_mutex_init(&mutex, NULL);

    struct timespec begin,end;
    double elapsed;
    clock_gettime(CLOCK_REALTIME, &begin);

    //sent borders of summarizing
    int* borders = (int*)calloc(n_threads*2,sizeof(int));
    int size = n_numbers/n_threads;
    for(int i = 0; i < n_threads-1; i++){
	    borders[2*i] = size*i+1;
	    borders[2*i+1] = size*(i+1);
        pthread_create(tid+i,&attr,summarize,borders+2*i);
    }
    borders[2*(n_threads-1)] = size*(n_threads-1)+1;
    borders[2*(n_threads-1)+1] = n_numbers;
    pthread_create(tid+(n_threads-1),&attr,summarize,borders+2*(n_threads-1));

    //waiting for threads
    for(int i =0; i < n_threads; i++){
        pthread_join(*(tid+i),NULL);
    }

    clock_gettime(CLOCK_REALTIME, &end);
    elapsed = end.tv_sec-begin.tv_sec;
    elapsed += (end.tv_nsec-begin.tv_nsec)/1000000000.0;
    printf("Time of total execution: %f sec\n", elapsed);
    printf("The result of summarizing(on %d threads) numbers 1,2,...,%d is %ld\n", n_threads, n_numbers, sum);

    pthread_mutex_destroy(&mutex);
    free(borders);

    return 0;
}

void* summarize(void* data)
{
    struct timespec begin,end;
    double elapsed;
    clock_gettime(CLOCK_REALTIME, &begin);

    //Summarizing
    int local_sum = 0;
    for(int i = *((int*)data); i <= *((int*)data+1); i++){
        local_sum += i;
    }
    //Add local result to sum
    pthread_mutex_lock(&mutex);
    sum += local_sum;
    pthread_mutex_unlock(&mutex);

    clock_gettime(CLOCK_REALTIME, &end);
    elapsed = end.tv_sec-begin.tv_sec;
    elapsed += (end.tv_nsec-begin.tv_nsec)/1000000000.0;
    printf("Time of execution on thread: %f sec\n", elapsed);

    pthread_exit(0);
}

