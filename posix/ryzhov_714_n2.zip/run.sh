./task2 5 1000
