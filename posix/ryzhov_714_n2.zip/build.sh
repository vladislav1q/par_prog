gcc task2.c -o task2 -pthread -lrt

